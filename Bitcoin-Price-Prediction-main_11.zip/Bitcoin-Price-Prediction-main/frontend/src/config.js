module.exports = global.config = {
    localhost: '127.0.0.1'
};